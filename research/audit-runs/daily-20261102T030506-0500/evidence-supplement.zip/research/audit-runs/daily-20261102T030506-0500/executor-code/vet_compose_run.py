from vet_run_common import *
import collections,copy
sys.path.insert(0,str(ROOT/'scripts'))
from audit_execution_gate import current_source_sufficient,timestamp
B=read(R/'execution-baseline.json');N=read(R/'individual-decisions.json');I=read(ROOT/'data/source_inventory.json');OLD={s['id']:s for s in read(R/'baseline-inventory.json')['sources']};CMP=read(R/'current-content-comparison.json');D=read(R/'discovery-ledger.json');end=now();rows=[];reviews=[];gaps=[];datechanges=[]
EXTRA={
 'usa-medvet-clinical-studies':['https://www.ccralliance.org/yale-status','https://vetcancerconcierge.com/clinical-trials/']+[u for u in E if 'therajan.com/' in u],
 'australia-uq-school-veterinary-clinical-trials':['https://news.uq.edu.au/2026-02-dogs-cancer-could-leave-lasting-legacy'],
 'switzerland-zurich-clinical-studies':[u for u in E if 'tierspital.uzh.ch/forschungsprojekte/' in u],
 'usa-castr-alliance-studies':['https://veterinaryclinicaltrials.org/s/feasibility-and-dose-optimization-clinical-trial-of-local-immunotherapy-for-solid-tumors-in-canine-cancer-patients-534230/?ref=gallery'],
 'usa-oklahoma-state-clinical-trials':['https://cvhs.okstate.edu/clinical-trials'],
 'canada-ovc-active-oncology-trials':['https://icci.uoguelph.ca/current-oncology-oncology-related-clinical-trials/'],
 'japan-kamogawa-oncology-news':['https://prtimes.jp/main/html/rd/p/000000002.000190324.html'],
}
unknown={'brazil-usp-loct-oncolytic-virus-program','brazil-usp-onvex-precision-oncology','br-usp-fmvz-clinical-recruitment-news'}
for s in I['sources']:
 sid=s['id'];old=OLD.get(sid,{});d=copy.deepcopy(N['sources'][sid]);urls=[s['master_url']]+s.get('fallback_urls',[])+EXTRA.get(sid,[])
 aa=[a for a in ATT if a['url'] in urls or a.get('source_id')==sid]
 # Use the underlying actual wrapper and method even when a shared URL serves several source decisions.
 unique={ (a['url'],a['method'],a.get('attempted_at')):a for a in aa};aa=list(unique.values());actual=[a for a in aa if a['method']!='restriction_review_no_request'];usable=[a for a in actual if a['result'] in ['retrieved_page','web_retrieved_page'] and a.get('text_length',0)>400];opened=bool(actual)
 current=[x for x in CMP if x['current_evidence'] in {a['evidence_file'] for a in aa}]
 d['evidence_refs']=list(dict.fromkeys(a['evidence_file'] for a in aa))
 d['roster_evidence_refs']=list(dict.fromkeys(a['evidence_file'] for a in usable)) if d['roster_complete'] else []
 d['change_reviews']=[{'current_evidence':x['current_evidence'],**N['documents'][x['url']]} for x in current if x['whole_text_equal'] is False and x['url'] in N['documents']]
 complete=bool(d['completion_basis']) and not d['remaining_available_steps'] and sid not in unknown
 row={'source_id':sid,'source_name':s['name'],'opened_this_run':opened,'attempted_urls':aa,'route_used':list(dict.fromkeys(a['method'] for a in actual)),'current_content_comparison':current,'previous_last_checked':old.get('last_checked'),'previous_last_checked_at':old.get('last_checked_at'),'previous_result':old.get('last_result'),'previous_fingerprint':old.get('content_fingerprint'),'processing_complete':complete,'processing_assessment':'not_established' if sid in unknown else 'executor_unfinished' if d['remaining_available_steps'] else 'current_reconciliation_done','content_sufficient':False,'protocols_seen':None,'current_roster':None,'reconciliation':d['catalog_comparison'],'current_finding':d['finding']}
 row['content_sufficient']=current_source_sufficient(row,d,ROOT,timestamp(B['started_at']),timestamp(end))
 if row['content_sufficient']:row['protocols_seen']=len(d['protocols']);row['current_roster']=d['protocols'];result='reachable';coverage='fully_reconciled'
 elif not opened:result='not_checked';coverage='not_checked'
 elif usable:result='partial';coverage='partial';row['protocols_seen']=len(d['protocols']) if d['protocols'] else None
 else:result='unreachable';coverage='unreachable'
 row['master_result']=result;row['coverage_result']=coverage
 if opened:
  at=max(timestamp(a['completed_at']) for a in actual if a.get('completed_at')).astimezone(NY).isoformat();s['last_checked']=at[:10];s['last_checked_at']=at;s['last_result']=result
  s['last_attempts']=aa;s['last_route_used']=row['route_used'];s['last_audit_run_id']=R.name;s['last_protocols_seen']=row['protocols_seen'];s['last_check_summary']=d['finding'];s['last_coverage_receipt']=str(REL/'receipt-final.json');s['content_sufficient']=row['content_sufficient']
  origin=next((E[a['url']] for a in actual if a['url']==s['master_url'] and a['method']=='shell_curl' and E.get(a['url'],{}).get('result')=='retrieved_page' and len(clinical(E[a['url']]))>400),None)
  if origin:s['content_fingerprint']='sha256:'+origin['text_sha256'];s['fingerprint_method']='Actual retrieved master text; not independent proof of clinical sufficiency';s['last_http_status']=origin.get('http_status')
  elif not s.get('content_fingerprint'):s['content_fingerprint']=None
  s['last_visit_timestamp_precision']='instant';s['last_coverage_gap']=None if row['content_sufficient'] else d['finding']
 else:
  # No request means no new last_checked, last_checked_at, result or fingerprint.
  row['restriction_review_is_not_a_new_visit']=True
 row['last_checked']=s.get('last_checked');row['last_checked_at']=s.get('last_checked_at');row['last_result']=s.get('last_result');row['current_fingerprint']=s.get('content_fingerprint');rows.append(row);reviews.append(d)
 datechanges.append({'source_id':sid,'new_source':sid not in OLD,'actual_new_visit':opened,'previous':{k:old.get(k) for k in ['last_checked','last_checked_at','last_result','content_fingerprint']},'new':{k:s.get(k) for k in ['last_checked','last_checked_at','last_result','content_fingerprint']},'attempt_evidence_refs':d['evidence_refs']})
 if not row['content_sufficient']:
  assessment='not_established' if sid in unknown else 'executor_unfinished' if d['remaining_available_steps'] else 'external_blocker'
  question=s.get('last_coverage_gap') or d['finding']
  if d['category']=='discovery_source_not_trial_roster':question='Which named therapeutic signals in this source have a current originating protocol and owner intake? '+d['catalog_comparison']
  gap={'source_id':sid,'category':d['category'],'processing_assessment':assessment,'question':question,'reason':d['finding'],'next_action':'Recheck the specific permitted current master/fallback daily; perform deeper primary review when a new primary signal appears or the separately recorded recheck becomes due. Preserve exact restrictions and original evidence dates.','evidence':{'source_id':sid,'attempted_urls':list(dict.fromkeys(a['url'] for a in aa)),'evidence_refs':d['evidence_refs']},'unperformed_steps':d['remaining_available_steps']}
  if assessment=='external_blocker':gap['completion_decision']={'remaining_fact':question,'routes_exhausted_evidence':[{'url':a['url'],'method':a['method'],'result':a['result'],'evidence_ref':a['evidence_file']} for a in aa],'available_reconciliation_done_evidence':sid+': '+d['completion_basis']+' '+d['catalog_comparison']}
  gaps.append(gap)
I['updated']='2026-11-02';write(ROOT/'data/source_inventory.json',I)
issues=[]
for item in N['issues'].values():
 item=copy.deepcopy(item);item['evidence_refs']=refs(item.get('manual_evidence_urls',[]))
 if not item['evidence_refs']:item['evidence_refs']=[str(REL/'individual-decisions.json')]
 if item['state']=='BLOCKED':item['restriction_or_unpublished_evidence_refs']=item['evidence_refs']
 issues.append(item)
receipt={'run_id':R.name,'mode':'DAILY GLOBAL WORK AUDIT','started_at':B['started_at'],'at':end,'baseline_main_sha':'519c8189e244e3c4acd924f21c7059828fae7f55','source_total':len(rows),'baseline_source_total':len(B['source_ids']),'attempted_total':sum(x['opened_this_run'] for x in rows),'content_sufficient_total':sum(x['content_sufficient'] for x in rows),'processing_complete_total':sum(x['processing_complete'] for x in rows),'source_result_counts':dict(collections.Counter(x['coverage_result'] for x in rows)),'executor_incomplete_source_ids':[x['source_id'] for x in rows if not x['processing_complete']],'discovery_regions_processed':len({q['region'] for q in D['queries']}),'discovery_passes':['current_undated','recent_seven_days'],'sources':rows}
write(R/'receipt-final.json',receipt);write(ROOT/'data/audit_source_coverage.json',receipt);write(R/'gap-review.json',{'original_run_id':R.name,'reviewed_at':end,'rows':gaps});write(R/'source-date-changes.json',{'run_id':R.name,'baseline_main_sha':receipt['baseline_main_sha'],'rows':datechanges});write(R/'reviews.json',reviews)
write(R/'execution-review.json',{'schema_version':1,'run_id':R.name,'ended_at':end,'added_source_ids':[s['id'] for s in I['sources'] if s['id'] not in B['source_ids']],'source_reviews':reviews,'issue_updates':issues,'discovery_queries':D['queries'],'discovered_urls':D['discovered_urls'],'leads':D['leads'],'deadline_review_ref':str(REL/'deadline-review.json'),'stop':{'reason':'completed_available_work','detail':'Current source/issue/selected-lead decisions are saved. Remaining clinical questions require new published primary facts, restoration of exact restricted routes, or Yulia medical/status decisions. Three USP restriction scopes remain not established and are not counted complete. Validators and publication/readback follow separately; no background continuation claimed.','evidence_refs':[str(REL/'individual-decisions.json'),str(REL/'discovery-ledger.json'),str(REL/'execution-deviations.json')]}})
write(R/'attempts.json',ATT)
with open(R/'attempts.jsonl','w') as f:
 for a in ATT:f.write(json.dumps(a,ensure_ascii=False)+'\n')
print('receipt', {k:v for k,v in receipt.items() if k not in ['sources']});print('remaining source steps',sum(len(d['remaining_available_steps']) for d in reviews));print('issue states',dict(collections.Counter(x['state'] for x in issues)))
