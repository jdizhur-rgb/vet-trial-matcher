from vet_run_common import *
from collections import Counter
import copy,urllib.parse
D=read(R/'discovery-ledger.json');N=read(R/'individual-decisions.json');I=read(ROOT/'data/source_inventory.json');stamp=now();newq=[]
for n in range(33,96):
 p=R/f'discovery-{n:03d}.json';d=read(p)
 for q in d['queries']:
  region=q.get('region',d.get('region'));country=q.get('country',d.get('country'));lang=q.get('language',d.get('language'))
  if n==95:lang='English'if len(newq)%2==0 else'Norwegian'
  newq.append({'region':region,'country':country,'language':lang,'pass':q['pass'],'query':q['query'],'evidence_refs':[str(p.relative_to(ROOT))],'attempted_at':d['started_at'],'completed_at':d['completed_at'],**({'recency':7}if q.get('recency')==7 else{})})
D['queries']+=newq
D['country_frontier']={}
for q in D['queries']:D['country_frontier'].setdefault(q['region'],set()).add(q['country']+' / '+q['language'])
D['country_frontier']={k:sorted(v)for k,v in D['country_frontier'].items()};D['named_frontier_expansion']={'at':stamp,'additional_countries':40,'additional_country_queries':len(newq),'weak_country_English_refinements':20,'scope':'Every concrete named country in the earlier frontier was searched, plus ten additional sub-Saharan/Caribbean countries. Local and English refinements preserved. Weak or foreign-only results do not establish absence of local studies.'}
D['unqueried_country_frontier']={'remaining_countries_not_enumerated_as_a_complete_census':'81 countries actually queried. Other world countries/languages remain outside this finite systematic discovery matrix; no exhaustive global absence claim.'}
# Selected clinical/program signals have individual decisions; one underlying question is shared across its linked documents.
A=[]
for p in sorted(R.glob('frontier-primary*-attempts.json')):A+=read(p)
byurl={x['url']:x for x in A};existing={x['url']for x in D['leads']};ghent='be-ghent-feline-mammary-gcn2-inhibitor';immu=[x['id']for x in read(ROOT/'data/trials_base.json')if 'immuvera'in x['id']]
def add(u,disposition,reason,issue=None,ids=None,comparison=None,extra=None):
 if u in existing:return
 a=byurl[u];row={'url':u,'discovered_at':a['attempted_at'],'reviewed_at':stamp,'disposition':disposition,'reason':reason,'evidence_refs':[a['evidence_file']],'unperformed_steps':[]}
 if issue:row['lead_issue_id']=issue
 if disposition in ['PENDING_EVIDENCE','BLOCKED']:row.update(primary_url=u,missing_primary_reason=reason)
 if ids:row.update(canonical_ids=ids,identity_comparison=comparison)
 if extra:row.update(extra)
 D['leads'].append(row);D['discovered_urls'].append(u);existing.add(u)
for u in byurl:
 if 'vetmeduni'in u:add(u,'PENDING_EVIDENCE','Official2016invitation and2020institutional magazine support feline alimentary-lymphoma surgery+chemotherapy+radiotherapy access with initial diagnostics owner-paid and protocol treatment funded. Neither establishes current2026intake. Exact canonical comparison found no established identical protocol; retain nonmatchable lead, not a new recruiting record.','lead:vienna-feline-alimentary-lymphoma')
 elif 'forskning.no'in u:add(u,'PENDING_EVIDENCE','The June2023NMBU article describes an unnamed12week pilot for dogs with lung metastases and a separately planned30dog dendritic-cell trial. Current Immuvera Nebumet/NEBULA programme was read; shared company/investigator does not prove identical intervention/cohort. No current NMBU full owner protocol or intake is published in these permitted routes.','lead:nmbu-unnamed-immunotherapy',extra={'candidate_existing_ids':immu,'identity_comparison':'Cannot equate unnamed NMBU pilot or dendritic-cell study with the four legacy Nebumet registration-country records merely by sponsor.'})
 elif 'hifasvet.com/id/'in u:add(u,'PENDING_EVIDENCE','Sponsor describes a randomized double-blind30dog phaseII HIFAS ONCO PET adjunct-after-surgery mammary carcinoma study, gradeIII/stageIV, two-year followup. Its current product page and linked2025brochure describe supportive nutrition; they do not publish current owner intake, study allocation/costs or establish treatment-only eligibility. The single feline SCC+ECT case is a different completed case signal. No exact canonical counterpart established.','lead:hifas-mammary-adjuvant')
 elif 'hifasvet'in u:add(u,'NOT_TREATMENT','Actual R&D-linked product/brochure describes a supportive nutritional supplement and case/reference evidence, not a current owner-enrollment protocol. The separate mammary adjunct clinical lead remains unresolved under lead:hifas-mammary-adjuvant.')
 elif 'xeptiva'in u:add(u,'NOT_TREATMENT','Current sponsor table identifies Xep01 oncologic-pain/osteoarthritis studies, not tumour-directed anticancer treatment; Xep02dermatitis and Xep05equinepain are also outside inclusion. Private data-room access was not requested or entered.')
 elif 'cathealth'in u:add(u,'NOT_TREATMENT','Actual current senior-cat/antiaging protocol explicitly excludes a cancer diagnosis; no therapeutic oncology trial.')
 elif 'helsinki.fi'in u:add(u,'NOT_TREATMENT','Actual full SOFTIS project page enumerates non-oncological surgical/antimicrobial/continence/hernia research and completed recruitment cohorts, not a current tumour-treatment owner invitation.')
 elif 'ugent.be'in u:add(u,'VERIFIED_EXISTING','Actual owner primary identifies GCN2-IN-6 before/after mammary surgery in cats at Ghent Merelbeke-Melle, free study drug with no promise of free surgery; it matches the same existing clinical cohort. Earlier today evidence was reused; the inadvertent later reread is separately preserved, not a new full verification date.',ids=[ghent],comparison='Exact drug GCN2-IN-6, cat mammary carcinoma, perioperative dosing and Ghent hospital/cohort match '+ghent)
 elif 'pubmed.ncbi.nlm.nih.gov/28987957'in u:add(u,'PENDING_EVIDENCE','Actual2017primary abstract reports CIGB-552 subcutaneous therapy in9dogs with heterogeneous spontaneous solid tumours; no current veterinary owner-access or recruiting protocol is established. Targeted2026search returns preclinical toxicology and human trials, not a current canine invitation. No exact canonical counterpart established.','lead:cigb552-historic-canine')
 elif 'sggw.edu.pl'in u:add(u,'NOT_TREATMENT','Actual old laboratory URL redirects to the current faculty landing page; same-URL Web retrieves an unknown-freshness archived research profile. The official archive was also read. Described gold-nanoparticle projects are preclinical/invitro/inovo programmes, without a published current patient recruitment protocol. No current trial absence for all Poland is inferred.')
 elif 'roncovet'in u:add(u,'NOT_TREATMENT','Actual ROncoVet-26 primary is an epidemiological veterinary cancer registry/data-collaboration programme, not a treatment trial. Login/dashboard was not entered.')
 elif 'immuvera.com'in u:add(u,'PENDING_EVIDENCE','Current primary names inhaled BCG Nebumet and NEBULA proof-of-concept in30dogs with advanced oral melanoma. Jan2026funding and Apr2026OMICA development news do not publish current recruiting sites, eligibility or owner coverage. Preserve four inactive legacy registration-country IDs; do not equate a proof-of-concept cohort with a planned broad registration trial or infer market access.','lead:immuvera-nebumet-current-access',extra={'candidate_existing_ids':immu,'identity_comparison':'Same named Nebumet platform as the four legacy records, but current30dog NEBULA cohort and prior planned registration-country cohorts are not established as identical; unresolved.'})
 elif 'frontiersin.org'in u:add(u,'NOT_TREATMENT','Primary published18September2026reports66retrospective feline sarcoma cases from2015–2024with postoperative bleomycin ECT. This is clinical outcome evidence, not current recruitment; it is retained separately with single-institution/no-control limitations, and no care-directory or editorial update.')
# Account for every returned URL at the search-screening layer without pretending snippets are primary visits or identity proof.
C=read(ROOT/'data/trials_base.json');source_by_url={s['master_url'].rstrip('/'):s['id']for s in I['sources']};catalog_by_url={}
for c in C:
 for k in ['url','registry_url','funding_source']:
  if c.get(k):catalog_by_url.setdefault(c[k].rstrip('/'),[]).append(c['id'])
sel={x['url']:x for x in D['leads']};screen={}
for n in range(33,96):
 p=R/f'discovery-{n:03d}.json';d=read(p);text='\n'.join(x['text']for x in d['result']['content']if x['type']=='text')
 for block in re.split(r'-{10,}\n',text):
  title=block.split('\n')[0];m=re.search(r'\((https?://[^\s]+)\)\s*$',title)
  if not m:continue
  u=m[1];row=screen.setdefault(u,{'url':u,'title':title,'search_evidence_refs':[],'method':'Search result screening; not a primary visit'})
  row['search_evidence_refs'].append(str(p.relative_to(ROOT)))
  if u in sel:row.update(disposition='selected_lead_accounted',lead_disposition=sel[u]['disposition'])
  elif u.rstrip('/')in source_by_url:row.update(disposition='existing_exact_inventory_route_reuse_today_source_decision',source_id=source_by_url[u.rstrip('/')])
  elif u.rstrip('/')in catalog_by_url:row.update(disposition='existing_exact_catalog_referenced_URL_reuse_today_per_trial_decisions',record_ids=sorted(set(catalog_by_url[u.rstrip('/')])),identity_limitation='Same URL reference is not a semantic duplicate or current-enrollment proof.')
  else:row['disposition']='not_selected_human_care_service_nononcological_historical_or_general_research_noise';row['scope']='No new recruiting therapeutic protocol adjudicated from this result; full returned text preserved. Known foreign trial indexes remain in the original source/per-trial receipts; care/service directories were not visited.'
write(R/'frontier-screening.json',list(screen.values()));write(R/'discovery-ledger.json',D)
# Four genuinely new official oncology research sources; no care or generic non-oncology provider is added.
new=[
('at-vetmeduni-feline-lymphoma-study','Vetmeduni Vienna — feline alimentary lymphoma clinical invitation','Austria','university_program','https://www.vetmeduni.ac.at/fileadmin/v/interne-kleintiere/onkologie/Katzenlymphomstudie_20160510.pdf',['https://www.vetmeduni.ac.at/fileadmin/v/oeuk/Magazin/2020/vetmed_2020_04_WEB.pdf'],'freshness_uncertain',['Feline alimentary lymphoma subtype-directed surgery/chemotherapy/radiotherapy'],'2016invitation and2020magazine read; full stated funded treatment and owner-paid diagnostics recorded, but current2026intake not established. This is an historical official therapeutic lead, not a current recruiting claim.'),
('es-hifasvet-oncology-research','Hifas Vet — oncology adjunct clinical research','Spain','sponsor_program','https://hifasvet.com/id/',['https://hifasvet.com/productos/#oncopet','https://hifasvet.com/wp-content/uploads/2025/03/Hifas_Onco_Pet_6.pdf'],'discovery_source_not_trial_roster',['30dog mammary carcinoma adjunct phaseII','Completed feline SCC+ECT case'],'R&D, linked product and actual brochure read; phaseIIpostoperative mammary adjunct distinguished from the single-cat SCC case and non-oncology studies. Current intake, complete trial costs and treatment-only clinical interpretation are not published; no canonical trial added.'),
('no-immuvera-nebumet-development','Immuvera Therapeutics — Nebumet clinical development','Norway','sponsor_program','https://www.immuvera.com/our-solution',['https://www.immuvera.com/news']+[u for u in byurl if 'immuvera.com/news/'in u],'discovery_source_not_trial_roster',['Nebumet inhaled BCG/NEBULA30dog oral-melanoma proof-of-concept','Planned confirmatory development'],'Current full solution/news/relevant development articles read. Compare exact named Nebumet with four inactive registration-country records; retain cohort/site/intake uncertainty and original dates. No new owner enrollment, public site roster or costs are stated; old NMBU unnamed/dendritic cohorts not merged by sponsor.'),
('pl-sggw-nanooncology-research','SGGW — experimental and clinical nanooncology research','Poland','university_program','https://imw.sggw.edu.pl/laboratory-of-experimental-and-clinical-nanooncology/?lang=en',['https://archiwumimw.sggw.edu.pl/'],'freshness_uncertain',['Preclinical gold nanoparticles canine OSA/feline injection-site sarcoma'],'Actual original URL redirects to generic faculty. Same official URL read in Web with2monthunknownfreshness; official archive fallback read. Gold-nanoparticle topics and preclinical references do not constitute current owner trial intake. No institutionwide unavailability or clinical roster asserted.')]
for sid,name,country,typ,master,fall,category,protocols,finding in new:
 if sid not in {s['id']for s in I['sources']}:I['sources'].append({'id':sid,'name':name,'country':country,'source_type':typ,'master_url':master,'fallback_urls':fall,'required_cadence':'daily','last_checked':None,'last_result':'not_checked','content_fingerprint':None,'source_role':'Official oncology clinical/research source; processing is distinct from current owner-intake/roster sufficiency.','notes':finding})
 N['sources'][sid]={'source_id':sid,'reviewed_at':stamp,'finding':finding,'protocols':protocols,'catalog_comparison':finding,'current_official_content':False,'roster_complete':False,'category':category,'remaining_available_steps':[],'completion_basis':finding+' All identified permitted source-specific clinical routes above were read; unresolved current intake or full protocol is not publicly established. No outreach.'}
write(ROOT/'data/source_inventory.json',I);write(R/'individual-decisions.json',N)
# Preserve actual Web timestamp/method in the standard reader schema.
p=R/'web-29.json';w=read(p);w['urls']=[w['url']];w['attempted_at']=w['started_at'];write(p,w)
# Durable unresolved questions deduplicate linked documents to one clinical issue.
p=ROOT/'data/audit_unresolved.json';U=read(p);items={x['id']:x for x in U['items']}
for lead in D['leads']:
 if lead.get('lead_issue_id')and lead['disposition']=='PENDING_EVIDENCE':
  lid=lead['lead_issue_id'];row=items.get(lid,{'id':lid,'status':'open','first_seen_at':lead['discovered_at'],'source_urls':[],'evidence_refs':[]});row.update(last_reviewed_at=stamp,record_ids=[],candidate_existing_ids=lead.get('candidate_existing_ids',[]),reason=lead['reason'],remaining_fact=lead['missing_primary_reason'],next_action='Read a new current named recruiting primary/site/protocol, or a new extension/intake signal; do not use an old publication or product page as present access.',recheck_after=(datetime.datetime.now(NY)+datetime.timedelta(days=7)).isoformat(),last_run_id=R.name);row['source_urls']=list(dict.fromkeys(row['source_urls']+[lead['url']]));row['evidence_refs']=list(dict.fromkeys(row['evidence_refs']+lead['evidence_refs']));items[lid]=row
U['items']=list(items.values());write(p,U)
write(R/'frontier-continuation.json',{'at':stamp,'reason':'Earlier provisional end decision superseded after finding concrete unqueried country frontier; all40named-country expansions and20weak English refinements now actually performed. No new run or fake fresh source dates.','queries':len(D['queries']),'countries':len({q['country']for q in D['queries']}),'lead_dispositions':dict(Counter(x['disposition']for x in D['leads'])),'available_remaining':[],'evidence_refs':[str(REL/'frontier-screening.json'),str(REL/'discovery-ledger.json')]})
print('queries',len(D['queries']),'countries',len({q['country']for q in D['queries']}),'sources',len(I['sources']),'leads',len(D['leads']),Counter(x['disposition']for x in D['leads']))
