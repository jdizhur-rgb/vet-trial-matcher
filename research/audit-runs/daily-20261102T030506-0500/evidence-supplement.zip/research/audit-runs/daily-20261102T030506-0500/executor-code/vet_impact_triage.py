import pathlib,json,datetime,hashlib,collections
from zoneinfo import ZoneInfo
ROOT=pathlib.Path('/workspace/scratch/55af69f9810e/audit-20261102');R=ROOT/'research/audit-runs/daily-20261102T030506-0500';REL=R.relative_to(ROOT)
def read(p):return json.loads(p.read_text())
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
at=datetime.datetime.now(ZoneInfo('America/New_York')).isoformat();N=read(R/'individual-decisions.json');X=read(R/'execution-review.json');B=read(R/'execution-baseline.json');C={x['id']:x for x in read(ROOT/'data/trials_base.json')};old={x['id']:x for x in read(R/'baseline-catalog.json')};pub=set(B['public_ids']);original={x['issue_id']:x for x in B['issues']};changes=[]
# These current blocked questions were individually read above; replace an inherited task label with the exact missing facts.
precise={
'wisc-ptcl-90y-nm600-rpt':'Does the current Wisconsin 90Y-NM600 peripheral-T-cell-lymphoma cohort accept new dogs, with what complete eligibility, treatment schedule and owner-cost coverage?',
'penn-psma-theranostic-prostate':'What current Penn PSMA-ligand prostate-cancer cohort, patient eligibility, treatment/site intake and screening-versus-treatment costs are confirmed by its individual primary?',
'penn-osa-car-inkt-newly-diagnosed':'Is the newly diagnosed Penn OSA CAR-iNKT cohort currently accepting dogs, and what exact prior-treatment, mandatory conventional treatment, sites and owner-cost criteria apply separately from the metastatic cohort?',
'penn-osa-carinkt':'Does the metastatic Penn OSA CAR-iNKT cohort currently enroll, and what are its full patient criteria, intake sites, study coverage and current study contacts?',
'penn-bcell-car-t-registry':'Which current Penn B-cell CAR-T cohort and intake site remain open, under what complete eligibility, treatment backbone and owner-cost terms?',
'jp-jsamc-feline-anti-pd1':'Does the JSAMC feline anti-PD-1 cohort currently enroll cats, and what diagnoses, full medical screening, participating sites and owner fees are published in its own primary protocol?'}
for issue in X['issue_updates']:
 if issue['trial_id']in precise and issue['question']=='Read the full primary protocol and reconcile current published facts.':
  changes.append({'issue_id':issue['issue_id'],'previous_question':issue['question'],'new_question':precise[issue['trial_id']],'basis':issue['finding'],'original_evidence_refs':issue['evidence_refs']});issue['question']=precise[issue['trial_id']];N['issues'][issue['issue_id']]['question']=issue['question']
X['ended_at']=at;X['stop']['detail']='Available current source/protocol/selected-lead work is adjudicated; final per-record impact triage separately preserves 45 outstanding clinical/selection record identities and eight additional daily-currentness gaps. Confirmed data/technical changes were deployed and live USA/Japan searches passed. Three USP restriction scopes remain not established. Remaining clinical facts require new published evidence/restored permitted access or Yulia decisions; full processing and clinical completion remain INCOMPLETE. Final evidence/report preservation follows.';X['stop']['evidence_refs'].append(str(REL/'catalog-impact-triage.json'))
write(R/'individual-decisions.json',N);write(R/'execution-review.json',X)
# First-seen of an inherited clinical issue was not established by creating a new owner-decision wrapper today.
p=ROOT/'data/audit_unresolved.json';u=read(p);ageamend=[]
for row in u['items']:
 if row.get('id','').startswith('execution-owner-'):
  iid=row['id'][len('execution-owner-'):];iid=iid.replace('full_protocol-','full_protocol:',1).replace('independent_selection-','independent_selection:',1)
  if iid in original and row.get('first_seen_at'):
   ageamend.append({'id':row['id'],'previous_first_seen_at':row['first_seen_at'],'new_first_seen_at':None,'reason':'Inherited baseline issue; original first-seen unknown, owner-decision wrapper creation is not issue age.'});row['owner_decision_recorded_at']=row['first_seen_at'];row['first_seen_at']=None;row['first_seen_basis']='Original clinical question date unknown; present in frozen execution baseline.'
write(p,u)
write(R/'accounting-amendment.json',{'at':at,'scope':'Precision of unresolved questions and original issue age; no source visit, clinical verification date, enrollment or matching change. Original archive snapshots retained.','question_amendments':changes,'age_amendments':ageamend})
P1={'ncsu-mammary-inspire','ncsu-canine-sts-xcsgel','ncsu-feline-oral-pivot-c','ethos-solid-relapse','ethos-epush-hsa','au-melbourne-hsa-autologous-vaccine-multicenter','jp-yamaguchi-canine-lymphoid-anti-cd20','tufts-hsa-liquid'}
S=read(R/'receipt-final.json')['sources'];byref=collections.defaultdict(list)
for s in S:
 for a in s['attempted_urls']:byref[a['evidence_file']].append((s['source_id'],a))
def evidence(refs):
 out=[]
 for ref in refs:
  p=ROOT/ref
  try:d=read(p)
  except Exception:d={}
  if isinstance(d,dict):out.append({'ref':ref,'url':d.get('url'),'method':d.get('method','See referenced actual retrieval wrapper; not a new visit'),'attempted_at':d.get('attempted_at',d.get('started_at')),'completed_at':d.get('completed_at'),'result':d.get('result'),'freshness_limit':'Web cache is not independently origin-fresh'if '/web-'in ref else None})
  else:out.append({'ref':ref,'method':'Saved review artifact; not a fresh external visit'})
 return out
rows=[]
for x in X['issue_updates']:
 tid=x['trial_id'];active=tid in pub;resolved=x['state']=='RESOLVED';impact='P1'if tid in P1 or resolved else'P0';decision='resolved_verified'if resolved else'decision_required'if x['state']=='OWNER_DECISION'else'retained_with_field_gap';refs=x['evidence_refs'];linked=sorted({sid for ref in refs for sid,a in byref.get(ref,[])})
 rows.append({'issue_id':x['issue_id'],'impact':impact,'record_ids':[tid],'linked_source_ids':linked,'public_before':active,'question':x['question'],'evidence':evidence(refs),'previous_primary_verified':old[tid].get('verified'),'first_seen':None,'first_seen_basis':'Unknown original issue date'if x['issue_id']in original else'New specific site-scoping question found in this run; initial clinical evidence remains separately timestamped','last_attempted_at':x['reviewed_at'],'decision':decision,'public_after':bool(C[tid].get('available_for_matching',True)),'remaining_fact':None if resolved else x['question'],'current_retention_support':x['finding'],'proposed_disposition':None if resolved or impact=='P1'else'Suspend this record from matching pending current primary confirmation or Yulia medical/status decision; proposal only, not applied automatically.','next_action':x['next_action'],'recheck_after':None,'recheck_policy':'Daily permitted master/fallback and deadline checks; deeper recheck when primary changes or within seven days; explicit restrictions are not retried. Owner decisions can be addressed now.','processing_assessment':'current_reconciliation_done'if resolved else'owner_decision'if x['state']=='OWNER_DECISION'else'external_blocker','unperformed_steps':[]})
# Additional currentness/date gaps are not silently converted into a full-protocol queue resolution.
tr=read(R/'trial-protocol-reviews.json');dl={x['record_id']:x for x in read(R/'deadline-review.json')['rows']}
for x in tr:
 if x['status']!='PARTIAL_CURRENTNESS_OR_DEADLINE_NOT_VERIFIED':continue
 tid=x['trial_id'];d=dl[tid];rr=[y['evidence_file']for y in d['Web_evidence']];rows.append({'issue_id':'daily-currentness:'+tid,'impact':'P1','record_ids':[tid],'public_before':True,'question':'Is there a current published recruitment cutoff or extension for this exact protocol/site, beyond retained clinical evidence or unknown-freshness cache?','evidence':evidence(rr)+[{'ref':str(REL/'deadline-review.json'),'method':'Current per-record comparison; not a new visit'}],'previous_primary_verified':old[tid].get('verified'),'first_seen':None,'last_attempted_at':d['compared_at'],'decision':'retained_with_field_gap','public_after':True,'remaining_fact':d['question'],'current_retention_support':'Existing canonical clinical evidence retained with its original date. No newly confirmed passed cutoff and no new full verification claimed. '+d['comparison_result'],'next_action':'Next daily permitted source/individual-primary review, and immediate review of any changed deadline signal; do not retry exact explicit restrictions.','recheck_after':None,'processing_assessment':'external_blocker','unperformed_steps':d['unperformed_steps']})
# Source completeness is a distinct question, never a claim that every trial of the institution is uncertain.
source_questions=[]
for gap in read(R/'gap-review.json')['rows']:
 source_questions.append({'issue_id':'source-completeness:'+gap['source_id'],'impact':'P3','source_id':gap['source_id'],'record_ids':[],'public_before':None,'question':'Source-completeness evidence only: '+gap['question'],'evidence':gap['evidence'],'previous_primary_verified':None,'first_seen':None,'last_attempted_at':next(s for s in S if s['source_id']==gap['source_id']).get('last_checked_at'),'decision':'not_established'if gap['processing_assessment']=='not_established'else'retained_with_field_gap','public_after':None,'remaining_fact':gap['question'],'next_action':gap['next_action'],'recheck_after':None,'processing_assessment':gap['processing_assessment'],'unperformed_steps':gap['unperformed_steps'],'clinical_issue_refs':[x['issue_id']for x in rows if gap['source_id']in x.get('linked_source_ids',[])]})
leads=[x for x in read(R/'discovery-ledger.json')['leads']if x['disposition']in['PENDING_EVIDENCE','BLOCKED']]
active={tid for x in rows if x['remaining_fact'] for tid in x['record_ids']if tid in pub};protocol={x['trial_id']for x in X['issue_updates']if x['state']!='RESOLVED'}&pub
out={'run_id':R.name,'reviewed_at':at,'unique_active_with_outstanding_protocol_selection_issues':len(protocol),'additional_daily_currentness_active_records':len(active-protocol),'unique_active_affected_including_currentness':len(active),'source_completeness_questions':len(source_questions),'unresolved_discovery_URLs':len(leads),'note':'P0 is the material unresolved fact or status proposal, not proof that a therapy is unsafe, closed or wrongly included. P1 retains confirmed core access and original clinical dates while ancillary/site/currentness facts remain limited. No automatic medical/status change. Source and candidate counts are not clinical trial counts.','clinical_issues':rows,'source_questions':source_questions,'nonmatchable_candidate_questions':[{'impact':'P2','record_ids':x.get('canonical_ids',[]),'public_before':False,'public_after':False,'url':x['url'],'disposition':x['disposition'],'question':x.get('missing_primary_reason',x['reason']),'evidence_refs':x['evidence_refs'],'unperformed_steps':x['unperformed_steps']}for x in leads]};write(R/'catalog-impact-triage.json',out);print({k:v for k,v in out.items()if not isinstance(v,(list,dict))});print('question amendments',len(changes),'age amendments',len(ageamend))
