from vet_run_common import *
from collections import Counter
# Compact public comparisons while retaining the complete original diff artifact.
p=R/'current-content-comparison.json';full=read(p)
if not (R/'comparison-diffs-full.json').exists():write(R/'comparison-diffs-full.json',full)
compact=[]
for c in full:
 x={k:v for k,v in c.items() if k!='diff_lines'};lines=c.get('diff_lines',[]);x['diff_line_count']=c.get('diff_line_count',len(lines));x['diff_evidence_ref']=str(REL/'comparison-diffs-full.json');x['diff_preview']=[v[:220] for v in lines[:12]];compact.append(x)
write(p,compact)
# Explicit actual access gates are durable exact-route holds; no institution-wide scope invented.
p=ROOT/'data/source_access_restrictions.json';a=read(p);known={x['url'].rstrip('/') for x in a['routes']}
for u,d in E.items():
 gate=d.get('result')=='explicit_access_gate' or 'ATTACK ATTEMPT DETECTED/SUSPICION' in d.get('text','')
 if not gate or u.rstrip('/') in known:continue
 a['routes'].append({'url':u,'do_not_retry':True,'observed_at':iso(d['completed_at']),'http_status':d.get('http_status'),'record_ids':[d['source_id']] if d.get('source_id') in {x['id'] for x in read(ROOT/'data/trials_base.json')} else [],'origin':d['evidence_file'],'reason':'Exact observed access gate; no shell/Web retry or institution-wide restriction inferred.'});known.add(u.rstrip('/'))
for u,origin,reason in [('https://studypages.com/api/v1/studycontent-latest-version/534230/en',str(REL/'execution-deviations.json'),'Automatic review denied an unestablished API route; no alternate API requests authorized.'),('https://www.rvc.ac.uk/Media/Default/Clinical%20Investigation%20Centre/Documents/WebsiteflyermetronomictherapytrialKMAL08042014.pdf',str(REL/'web-28.json'),'Same official primary PDF returned Web403 after bounded shell connection failure; exact route not retried.')]:
 if u.rstrip('/') not in known:a['routes'].append({'url':u,'do_not_retry':True,'observed_at':now(),'http_status':403 if 'rvc.ac.uk' in u else None,'record_ids':[],'origin':origin,'reason':reason});known.add(u.rstrip('/'))
a['updated']='2026-11-02';write(p,a)
# Per-public-trial status distinguishes a fresh full review from the permitted unchanged-roster path.
N=read(R/'individual-decisions.json');B=read(R/'execution-baseline.json');C={x['id']:x for x in read(ROOT/'data/trials_base.json')};dl={x['record_id']:x for x in read(R/'deadline-review.json')['rows']};byold={x['trial_id']:x for x in B['issues'] if x['kind']=='full_protocol'};reviews=[]
for tid in B['public_ids']:
 issue=N['issues'].get('full_protocol:'+tid);dates=dl[tid];row={'trial_id':tid,'primary_url':C[tid].get('url'),'previous_verified':dates['previous_verified'],'current_verified':C[tid].get('verified'),'reviewed_at':now(),'current_evidence':dates['current_primary_evidence'],'Web_evidence':dates['Web_evidence'],'source_verification_date_refreshed':bool(issue and issue['state']=='RESOLVED')}
 if issue and issue['state']=='RESOLVED':row.update(status='VERIFIED_CURRENT',facts_checked=issue['facts_checked'],finding=issue['finding'],evidence_refs=refs(issue['manual_evidence_urls']))
 elif issue:row.update(status='BLOCKED' if issue['state']=='BLOCKED' else 'PARTIAL_OWNER_DECISION',queue_state=issue['state'],remaining_fact=issue['question'],finding=issue['finding'],evidence_refs=refs(issue['manual_evidence_urls']))
 else:
  row.update(status='CURRENT_PRIMARY_OR_ROSTER_RECONCILED_DEEP_REVIEW_NOT_DUE' if dates['current_primary_evidence'] else 'PARTIAL_CURRENTNESS_OR_DEADLINE_NOT_VERIFIED',finding='Current individual evidence and source roster/changed-document decisions retained. No full deep reread date is claimed. Published deadlines were compared separately; prior clinical verification remains unchanged.',evidence_refs=[x['evidence_ref'] for x in dates['current_primary_evidence']]+[x['evidence_file'] for x in dates['Web_evidence']])
 reviews.append(row)
write(R/'trial-protocol-reviews.json',reviews)
# Durable new leads and owner decisions supplement, never replace or auto-close, older unresolved work.
p=ROOT/'data/audit_unresolved.json';u=read(p);items={x['id']:x for x in u['items']}
for lead in read(R/'discovery-ledger.json')['leads']:
 if lead['disposition'] not in ['PENDING_EVIDENCE','BLOCKED']:continue
 lid='discovery-'+hashlib.sha256(lead['url'].encode()).hexdigest()[:18]
 old=items.get(lid,{});items[lid]={**old,'id':lid,'status':'open','first_seen_at':old.get('first_seen_at',lead['discovered_at']),'last_reviewed_at':lead['reviewed_at'],'reason':lead['reason'],'remaining_fact':lead.get('missing_primary_reason'),'source_urls':[lead['url']],'record_ids':lead.get('canonical_ids',[]),'evidence_refs':lead['evidence_refs'],'next_action':'Review a newly published current individual primary or restored exact permitted route; do not infer current access from an old announcement.','recheck_after':(datetime.datetime.now(NY)+datetime.timedelta(days=7)).isoformat(),'last_run_id':R.name}
for iid,row in N['issues'].items():
 if row['state']!='OWNER_DECISION':continue
 lid='execution-owner-'+iid.replace(':','-');old=items.get(lid,{});items[lid]={**old,'id':lid,'status':'owner_decision','first_seen_at':old.get('first_seen_at',row['reviewed_at']),'last_reviewed_at':row['reviewed_at'],'record_ids':[row['trial_id']],'reason':row['finding'],'remaining_fact':row['question'],'next_action':row['next_action'],'source_urls':row['manual_evidence_urls'],'evidence_refs':refs(row['manual_evidence_urls']),'last_run_id':R.name}
u['items']=list(items.values());u['updated']='2026-11-02';write(p,u)
print('public trial scope',dict(Counter(x['status'] for x in reviews)),'holds',len(a['routes']))
