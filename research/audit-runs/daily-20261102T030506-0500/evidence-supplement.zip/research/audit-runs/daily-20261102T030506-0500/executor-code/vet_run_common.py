import pathlib,json,re,datetime,hashlib,sys
from zoneinfo import ZoneInfo
ROOT=pathlib.Path('/workspace/scratch/55af69f9810e/audit-20261102');R=pathlib.Path(open('/tmp/vet-nov2-run').read().strip());REL=R.relative_to(ROOT);NY=ZoneInfo('America/New_York')
def read(p):return json.loads(pathlib.Path(p).read_text())
def write(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def now():return datetime.datetime.now(NY).isoformat()
def iso(x):
 if not x:return None
 if x.endswith(' UTC'):return datetime.datetime.strptime(x,'%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=datetime.timezone.utc).isoformat()
 return datetime.datetime.fromisoformat(x.replace('Z','+00:00')).isoformat()
E={d.get('url'):d for p in (R/'evidence').glob('*.json') for d in [read(p)] if d.get('url')}
WEB={};ATT=[]
for u,d in E.items():
 a={k:v for k,v in d.items() if k not in ['text','clinical_text','links','public_content','restriction','cache_headers']};a['attempted_at']=iso(a.get('attempted_at'));a['completed_at']=iso(a.get('completed_at'));a['new_source_visit']=a.get('method')!='restriction_review_no_request';ATT.append(a)
for p in sorted(R.glob('web-[0-9]*.json')):
 d=read(p)
 if not isinstance(d,dict):continue
 text='\n'.join(c.get('text','') for c in d.get('result',{}).get('content',[]) if c.get('type')=='text');urls=d.get('urls',[])
 if p.name=='web-27.json':urls=['https://forms.gle/ZGfDKxjJ8SS5VKyA6']
 parts=re.split(r'\n-{10,}\n',text)
 for i,u in enumerate(urls):
  candidates=[part for part in parts if u in part];part=candidates[0] if candidates else parts[i] if i<len(parts) else text
  # Keep method, retrieval time and crawl metadata separate; no inferred origin visit.
  body=bool(re.search(r'Total lines: [1-9][0-9]',part)) or bool(re.search(r'Content type: application/pdf',part))
  a={'url':u,'method':'Web','attempted_at':iso(d.get('attempted_at')),'completed_at':iso(d.get('completed_at')),'evidence_file':str(p.relative_to(ROOT)),'result':'web_retrieved_page' if body else 'web_unavailable','new_source_visit':True,'http_status':None,'freshness':'same-day crawl metadata' if 'Crawled: today;' in part else 'cache freshness not independently established','text_length':len(part)}
  ATT.append(a);WEB.setdefault(u,[]).append({**a,'text':part})
def refs(urls):
 out=[]
 for u in urls:
  if u in E:out.append(E[u]['evidence_file'])
  out.extend(a['evidence_file'] for a in WEB.get(u,[]))
 return list(dict.fromkeys(out))
def clinical(d):
 t=d.get('visual_clinical_text') or d.get('clinical_text') or d.get('text','')
 if len(t)<400 and d.get('public_content'):t+='\n'+json.dumps(d['public_content'],ensure_ascii=False)
 return t
