import json,pathlib,datetime
from zoneinfo import ZoneInfo
ROOT=pathlib.Path('/workspace/scratch/55af69f9810e/audit-20261102');R=pathlib.Path(open('/tmp/vet-nov2-run').read().strip());S=json.loads((ROOT/'data/source_inventory.json').read_text())['sources'];C=json.loads((ROOT/'data/trials_base.json').read_text());B=json.loads((R/'execution-baseline.json').read_text())
def now():return datetime.datetime.now(ZoneInfo('America/New_York')).isoformat()
def readnotes():return json.loads((R/'individual-decisions.json').read_text()) if (R/'individual-decisions.json').exists() else {'sources':{},'issues':{},'documents':{},'protocol_reviews':{}}
def save(d):(R/'individual-decisions.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def source(i,finding,protocols,comparison,*,sufficient=False,category='protocol_uncertainty',steps=None,completion=None):
 d=readnotes();sid=S[i]['id'];d['sources'][sid]={'source_id':sid,'reviewed_at':now(),'finding':finding,'protocols':protocols,'catalog_comparison':comparison,'current_official_content':sufficient,'roster_complete':sufficient,'category':category,'remaining_available_steps':steps or [],'completion_basis':completion or finding};save(d)
def issue(tid,finding,state='BLOCKED',question=None,next_action=None,facts=None,cases=None,refs=None,recheck=None):
 d=readnotes()
 for x in B['issues']:
  if x['trial_id']!=tid:continue
  row={'issue_id':x['issue_id'],'trial_id':tid,'kind':x['kind'],'reviewed_at':now(),'finding':finding,'state':state,'question':question or x['question'],'next_action':next_action or 'Review a newly published or restored permitted primary protocol; retain the original clinical evidence date until that review is complete.','manual_evidence_urls':refs or [x['primary_url']]}
  if facts:row['facts_checked']=facts
  if cases and x['kind']=='independent_selection':row['cases_checked']=cases
  if recheck:row.update(recheck)
  d['issues'][x['issue_id']]=row
 save(d)
def document(url,finding,impact):
 d=readnotes();d['documents'][url]={'reviewed_at':now(),'finding':finding,'catalog_impact':impact};save(d)
def protocol(tid,facts,refs=None,complete=True,remaining=None):
 d=readnotes();d['protocol_reviews'][tid]={'trial_id':tid,'reviewed_at':now(),'facts_checked':facts,'manual_evidence_urls':refs or [],'review_complete':complete,'remaining_fact':remaining};save(d)
