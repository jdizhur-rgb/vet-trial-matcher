'use strict';
const fs=require('fs'),vm=require('vm');
const source=fs.readFileSync('seo/site/matcher/matcher.js','utf8');
const rows=JSON.parse(fs.readFileSync('seo/site/matcher/trials.json','utf8'));
async function run(country){
 const listeners={}, result={innerHTML:'',scrollIntoView(){}};
 const fields=Object.fromEntries(['tumor_status','metastasis','localized','brain_present','lymphoma_type','lymphoma_response','leukemia_status','mct_grade','node_status','osa_location','hsa_site','standard_therapy_unavailable','large_inoperable_or_rt_preferred','surgery_or_rt_not_possible','ct_and_current_biopsy','surgery','prior_procedure','chemo','immunotherapy_history','radiation','steroids','immunosuppressive','radiation_affordability'].map(k=>[k,"I don't know"]));
 Object.assign(fields,{species:'Dog',country,cancer:'Cancer — any type',diagnosis_status:"I don't know",age:'',weight:'',weight_unit:'lb',approach:'',zip_code:'',unlisted_diagnosis:''});
 const elements=Object.fromEntries(Object.entries(fields).map(([k,value])=>[k,{value,options:[{value}]}]));
 const dummy={addEventListener(){}};
 const form={elements,addEventListener(n,fn){listeners[n]=fn},querySelector(){return dummy},querySelectorAll(){return ['Chemotherapy','Radiation','Surgery','Immunotherapy','Targeted therapy','Experimental drug'].map(value=>({value}));},requestSubmit(){return listeners.submit({preventDefault(){}})}};
 const document={querySelector(s){return s==='#matcher-form'?form:s==='#matcher-results'?result:dummy},querySelectorAll(){return []}};
 vm.runInNewContext(source,{window:{location:{hash:'',search:''},MATCHER_DATA_URL:'./trials.json'},document,FormData:class{entries(){return Object.entries(fields)}},URLSearchParams,fetch:async()=>({ok:true,json:async()=>rows}),console});
 await form.requestSubmit(); await new Promise(r=>setImmediate(r));
 fs.writeFileSync('research/audit-runs/daily-20261102T030506-0500/expected-'+country+'.html',result.innerHTML);
}
(async()=>{await run('USA');await run('Japan')})().catch(e=>{console.error(e);process.exitCode=1});
