import os,json,pathlib,hashlib,subprocess,datetime,concurrent.futures,urllib.parse,threading,time,sys,re
from html.parser import HTMLParser
import html
ROOT=pathlib.Path('/workspace/scratch/55af69f9810e/audit-20261102');os.chdir(ROOT);sys.path.insert(0,str(ROOT));from scripts.check_evidence_keys import redact_text
R=pathlib.Path(open('/tmp/vet-nov2-run').read().strip()); E=R/'evidence';E.mkdir(exist_ok=True); RAW=pathlib.Path('/tmp/vet-nov2-raw');RAW.mkdir(exist_ok=True)
S=json.load(open('data/source_inventory.json'))['sources']; restrictions=json.load(open('data/source_access_restrictions.json'))['routes']
for s in S:restrictions+=s.get('access_restrictions',[])
def norm(u):
 p=urllib.parse.urlsplit(u);return (p.netloc.lower().removeprefix('www.'),p.path.rstrip('/'),p.query)
restricted={norm(x['url']):x for x in restrictions if x.get('do_not_retry')}
lock=threading.Lock();sem={}; memo={}
def now():return datetime.datetime.now(datetime.timezone.utc).astimezone().isoformat()
def extract(body,ctype,url):
 if 'pdf' in ctype:
  raw=RAW/(hashlib.sha256(url.encode()).hexdigest()[:18]+'.pdf');raw.write_bytes(body)
  p=subprocess.run(['pdftotext','-layout',str(raw),'-'],capture_output=True);return p.stdout.decode(errors='replace'),[],{}
 txt=body.decode('utf-8',errors='replace')
 if 'json' in ctype:
  try:
   obj=json.loads(txt)
   if 'studycontent-latest-version/' in url and isinstance(obj,dict):
    obj={k:v for k,v in obj.items() if k in ['avma_id','content','iacuc_number','investigators','is_snoozed','managed_locations','multi_locations','org_study_sites_management_enabled','schema_version']}
    if isinstance(obj.get('content'),dict):
     obj['content']={k:v for k,v in obj['content'].items() if k not in ['ai_managed','banner_preview_url','logo_preview_url','logo_preview_url_or_none','video_thumb_url','video_url']}
   return json.dumps(obj,ensure_ascii=False,sort_keys=True),[],{}
  except: return txt,[],{'json_parse_failed':True}
 class Page(HTMLParser):
  def __init__(self):super().__init__();self.text=[];self.links=[];self.islands={};self.skip=0;self.script_id=None;self.script=[];self.a=None
  def handle_starttag(self,t,attrs):
   d=dict(attrs)
   if t in ['script','style','noscript']:
    self.skip+=1
    if t=='script':self.script_id=d.get('id');self.script=[]
   if t=='a' and 'href' in d:self.a={'text':'','url':urllib.parse.urljoin(url,d['href'])};self.links.append(self.a)
  def handle_endtag(self,t):
   if t in ['script','style','noscript']:
    if self.script_id in ['d_sv_content','d_sv_values','d_sv_flags','d_sv_locations_display','d_sv_investigators_list','d_sv_study_pdfs','d_sv_public_irb_info']:
     try:self.islands[self.script_id]=json.loads(''.join(self.script))
     except:pass
    self.script_id=None;self.skip=max(0,self.skip-1)
   if t=='a':self.a=None
  def handle_data(self,d):
   if self.script_id:self.script.append(d)
   if self.skip:return
   if d.strip():self.text.append(d.strip())
   if self.a is not None:self.a['text']+=d
 p=Page();p.feed(txt);islands=p.islands;links=p.links;text='\n'.join(p.text)
 if 'd_sv_values' in islands:
  keys=['publicId','studypageStatus','studyStartDate','studyEndDate','contactName','contactEmail','spPhoneConditional','iacucNumber','avmaId','studyCode']
  islands['d_sv_values']={k:v for k,v in islands['d_sv_values'].items() if k in keys}
 if 'd_sv_flags' in islands:
  keys=['is_studypage_active','is_active','is_active_nyr','is_finished_rec','join_button_enabled','requires_login']
  islands['d_sv_flags']={k:v for k,v in islands['d_sv_flags'].items() if k in keys}
 return text,links,islands

def get(task):
 url=task['url']; key=hashlib.sha256(url.encode()).hexdigest()[:18];path=E/(key+'.json');start=now()
 if norm(url) in restricted:
  result={**task,'method':'restriction_review_no_request','attempted_at':start,'completed_at':now(),'result':'saved_exact_restriction','restriction':restricted[norm(url)],'evidence_file':str(path.relative_to(ROOT)),'new_source_visit':False,'text':''};path.write_text(json.dumps(result,ensure_ascii=False,indent=2));return result
 host=urllib.parse.urlsplit(url).netloc
 with lock: sm=sem.setdefault(host,threading.Semaphore(2))
 with sm:
  attempts=[]
  for retry in range(2):
   bodypath=RAW/(key+'.body');hdrpath=RAW/(key+'.headers')
   proc=subprocess.run(['curl','--connect-timeout','5','--max-time','20','--max-redirs','5','-L','-sS','-D',str(hdrpath),'-o',str(bodypath),'-w','%{http_code}\n%{content_type}\n%{url_effective}',url],capture_output=True,text=True)
   parts=proc.stdout.splitlines();status=int(parts[0]) if parts and parts[0].isdigit() else 0;ctype=parts[1] if len(parts)>1 else '';effective=parts[2] if len(parts)>2 else url
   h=hdrpath.read_text(errors='replace') if hdrpath.exists() else '';body=bodypath.read_bytes() if bodypath.exists() else b''
   attempts.append({'at':now(),'http_status':status,'exit_code':proc.returncode,'stderr':proc.stderr[:500],'retry':retry})
   if retry==0 and (proc.returncode==28 or status==429 or status>=500):
    ra=re.search(r'^retry-after:\s*(\d+)',h,re.I|re.M);pause=int(ra[1]) if ra else 0
    if pause>30:break
    if pause:time.sleep(pause)
    continue
   break
  text,links,islands=extract(body,ctype,effective)
  gate=status in [401,403] or bool(re.search(r'captcha|verify you are human|access denied|attention required!|just a moment',text[:2000],re.I))
  result={**task,'method':'shell_curl','attempted_at':start,'completed_at':now(),'http_status':status or None,'effective_url':effective,'content_type':ctype,'attempts':attempts,'result':'explicit_access_gate' if gate else 'retrieved_page' if status==200 else 'transport_or_http_error','text_length':len(text),'text_sha256':hashlib.sha256(text.encode()).hexdigest(),'text':text,'links':links,'public_content':islands,'evidence_file':str(path.relative_to(ROOT)),'cache_headers':{k:v for k,v in [z.split(':',1) for z in h.splitlines() if ':' in z] if k.lower() in ['date','age','last-modified','x-cache']}}
  path.write_text(redact_text(json.dumps(result,ensure_ascii=False,indent=2)))
  return {k:v for k,v in result.items() if k not in ['text','links','public_content','cache_headers']}
def main():
 tasks=[]
 if len(sys.argv)>1: tasks=json.load(open(sys.argv[1]))
 else:
  seen=set()
  for s in S:
   for route,u in [('master',s['master_url'])]+[('official_fallback',u) for u in s.get('fallback_urls',[])]:
    if u in seen:continue
    seen.add(u);tasks.append({'source_id':s['id'],'url':u,'route':route})
 out=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  for i,r in enumerate(ex.map(get,tasks)):
   out.append(r)
   with open(R/(sys.argv[2] if len(sys.argv)>2 else 'protocol-shell-attempts.json' if len(sys.argv)>1 else 'shell-attempts.json'),'w') as f:json.dump(out,f,indent=2,ensure_ascii=False)
   print(i,r['source_id'],r.get('http_status'),r.get('result'),r.get('text_length',0),flush=True)
 print('DONE',len(out))
if __name__=='__main__':main()
