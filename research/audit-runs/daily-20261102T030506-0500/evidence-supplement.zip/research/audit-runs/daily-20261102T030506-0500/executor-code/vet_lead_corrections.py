from vet_run_common import *
p=R/'discovery-ledger.json';d=read(p);c=read(ROOT/'data/trials_base.json');n=read(R/'individual-decisions.json')
fullmaps={'https://www.gamgee.io/trial/':['au-gamgee-personalized-mrna-vaccine'],'https://www.caudjlab.com/newdetail.aspx?id=73':['china-dongjun-mct-new-drug-2026','china-dongjun-osa-new-drug-2026','china-dongjun-oral-scc-new-drug-2026'],'https://www.egah.com.tw/news/%E6%8B%9B%E5%8B%9F%E7%8A%AC%E9%BB%91%E8%89%B2%E7%B4%A0%E7%98%A4%E5%8F%8A%E9%AA%A8%E8%82%89%E7%98%A4%E8%87%A8%E5%BA%8A%E8%A9%A6%E9%A9%97':['taiwan-evergreen-il15-melanoma-osa'],'https://www.coloradoanimalspecialty.com/clinical-studies/exploratory-field-trial':['mizzou-bcell-btk-bi705564']}
for x in d['leads']:
 u=x['url'];e=E.get(u,{})
 if u in fullmaps:
  x.update(disposition='VERIFIED_EXISTING',canonical_ids=fullmaps[u],primary_url=u,identity_comparison='Current actual individual primary intervention, disease/cohort, species, country/sites, eligibility and funding were reconciled in today\'s17complete clinical reviews: '+ ' | '.join(n['issues']['full_protocol:'+tid]['finding'] for tid in fullmaps[u]));x.pop('missing_primary_reason',None)
 elif x['disposition']=='SOURCE_INDEX_REVIEWED' and e.get('result') in ['saved_exact_restriction','explicit_access_gate']:
  x.update(disposition='BLOCKED',missing_primary_reason='Exact previously recorded access/scope restriction prevents a fresh read of this URL. Incidental cached search content is not a new visit or a verified roster. Related independent permitted primary evidence is recorded separately.');x.pop('protocol_links_examined',None)
 elif 'health.adelaide.edu.au' in u:
  x.update(disposition='PENDING_EVIDENCE',missing_primary_reason='Official historical FIDO flyer now redirects to college content; targeted current-source searches established no current individual recruitment/complete protocol. No date renewed or source absence inferred.');x.pop('protocol_links_examined',None)
 elif 'saaca.org.za' in u:
  x.update(disposition='NOT_TREATMENT',reason='Actual SAACA page is a research/charity programme and support context, not a named owner-recruiting anticancer trial. Care services/funding programmes are not promoted into treatment matching.');x.pop('protocol_links_examined',None)
 elif 'slu.se/' in u:
  x.update(disposition='PENDING_EVIDENCE',missing_primary_reason='Current project/investigator/grant documents identify OXC101 research but do not publish current owner cohort, full eligibility, site allocation or costs. Project funding dates do not establish intake.');x.pop('protocol_links_examined',None)
 # Each index retains its actual enumerated protocol identities/dispositions; exact held URLs cannot be claimed read.
 x['reviewed_at']=now()
def evidence(u):return refs([u])+[str(p.relative_to(ROOT)) for p in R.glob('discovery-[0-9]*.json') if u in p.read_text()]
new=[{'url':'https://www.rvc.ac.uk/Media/Default/Clinical%20Investigation%20Centre/Documents/WebsiteflyermetronomictherapytrialKMAL08042014.pdf','disposition':'BLOCKED','reason':'Potential metronomic treatment flyer returned by targeted UK expansion was attempted with bounded shell and same-URL Web. Web explicitly returned403; the exact route is now held. Filename indicates2014, not current enrollment evidence.','missing_primary_reason':'Current metronomic cohort, eligibility/costs and present intake were not established; no existing canonical protocol identity asserted.'}, {'url':'https://fr.linkedin.com/posts/laura-barrett-dvm_heureuse-dannoncer-louverture-des-inclusions-activity-7325507044227145729-BBEm','disposition':'VERIFIED_EXISTING','reason':'The public historical post describes intratumoral immunotherapy for unresectable canine oral melanoma/oralSCC or declinedSOC, funded study. The current originating VetAgro individual primary was already actually read in this run.','primary_url':'https://www.vetagro-sup.fr/recherche-expertise/cicv-centre-investigation-clinique-veterinaire/etude-pour-developper-un-nouveau-medicament-pour-traiter-les-melanomes-et-carcinomes-epidermoides-buccaux/','canonical_ids':['eu-fr-oral-intratumoral-immunotherapy'],'identity_comparison':'Same oral-melanoma/oralSCC intratumoral investigational treatment, VetAgro/LauraBarrett and clinical intake; no unrelated protocol merged because of the institution name.'}]
for x in new:
 if x['url'] in {z['url'] for z in d['leads']}:continue
 x.update(reviewed_at=now(),discovered_at=now(),unperformed_steps=[],evidence_refs=list(dict.fromkeys(evidence(x['url'])+refs([x.get('primary_url','')]))));d['leads'].append(x)
d['discovered_urls']=[x['url'] for x in d['leads']];write(p,d)
print('final selected leads',len(d['leads']),'evidence absent',[x['url'] for x in d['leads'] if not x['evidence_refs']])
