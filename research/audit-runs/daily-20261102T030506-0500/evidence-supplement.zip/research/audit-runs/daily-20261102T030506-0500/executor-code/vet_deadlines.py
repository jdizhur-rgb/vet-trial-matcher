from vet_run_common import *
B=read(R/'execution-baseline.json');C=read(ROOT/'data/trials_base.json');OLD={x['id']:x for x in read(R/'baseline-catalog.json')};notes=read(R/'individual-decisions.json');rows=[]
for t in C:
 tid=t['id'];o=OLD[tid];urls=list(dict.fromkeys([u for u in [t.get('funding_source'),t.get('url'),t.get('registry_url'),t.get('recruitment_end_source')] if u]))
 urls += [u for u,d in E.items() if d.get('source_id')==tid and u not in urls]
 # Join actual observed protocol public-content requests by their public identity.
 publicids={m.group(1) for u in urls for m in re.finditer(r'-(\d{6})/?(?:\?|$)',u)}
 urls += [u for u in E if any('/'+i+'/en' in u or re.search(r'-'+i+r'/?(?:\?|$)',u) for i in publicids) and u not in urls]
 attempts=[a for a in ATT if a['url'] in urls];valid=[E[u] for u in urls if u in E and E[u].get('result')=='retrieved_page' and (len(clinical(E[u]))>400)];web=[a for u in urls for a in WEB.get(u,[]) if a['result']=='web_retrieved_page'];restr=[a for a in attempts if a['method']=='restriction_review_no_request']
 # Original canonical verification dates are history, not new primary-reading dates.
 dates=[]
 for key in ['recruitment_end','enrollment_end','recruitment_deadline','enrollment_deadline']:
  if t.get(key):dates.append({'raw_text':str(t[key]),'normalized_date':str(t[key])[:10],'type':'stored_recruitment_cutoff_requires_primary_semantics','scope':tid,'timezone':None,'source':'canonical:'+key})
 for d in valid:
  pc=d.get('public_content',{});values=pc.get('d_sv_values',{})
  if values.get('studyEndDate'):dates.append({'raw_text':values['studyEndDate'],'type':'study_period_end_not_automatically_recruitment','scope':tid,'timezone':None,'primary_url':d['url'],'evidence_ref':d['evidence_file'],'original_read_at':d['completed_at']})
  if 'studycontent-latest-version' in d['url']:
   try:
    obj=json.loads(d['text']);content=obj.get('content',{})
    if content.get('end_date'):dates.append({'raw_text':str(content['end_date']),'type':'structured_study_period_end_not_automatically_recruitment','scope':tid,'timezone':None,'primary_url':d['url'],'evidence_ref':d['evidence_file'],'original_read_at':d['completed_at']})
   except:pass
  for line in clinical(d).splitlines():
   if len(line)<900 and re.search(r'recruit|enrol|deadline|募集期間|研究期間|截止|截至|hasta|Date de fin|until|through',line,re.I) and re.search(r'20\d\d|October\s+30|September\s+30',line,re.I):dates.append({'raw_text':line,'type':'date_candidate_not_adjudicated_from_keywords','scope':tid,'timezone':None,'primary_url':d['url'],'evidence_ref':d['evidence_file'],'original_read_at':d['completed_at']})
 outcome='current_primary_text_examined_for_dates_no_explicit_cutoff_established' if valid else 'Web_content_only_freshness_not_independently_verified' if web else 'NOT_VERIFIED_exact_restriction' if restr else 'NOT_VERIFIED_no_current_individual_primary_text'
 question=None;unperformed=[]
 if tid in B['public_ids'] and not valid and not web and not restr:unperformed=['Obtain and review a current individual primary protocol or published official replacement; source-index presence alone is insufficient.']
 if tid=='ncsu-canine-ucc-il12':
  dates.append({'raw_text':'Enrollment Finish 09/30/2026','normalized_date':'2026-09-30','type':'explicit_recruitment_cutoff','scope':tid,'timezone':'America/New_York; date only, no published hour','primary_url':'https://cvm.ncsu.edu/clinical-trial/now-enrolling-dogs-with-invasive-bladder-cancer/','evidence_refs':refs(['https://cvm.ncsu.edu/clinical-trial/now-enrolling-dogs-with-invasive-bladder-cancer/'])});outcome='deadline_passed_no_published_extension_current_protocol_read';question=None;unperformed=[]
 if tid=='ncsu-liver-inspire':
  dates.append({'raw_text':'Enrollment Start07/01/2023; Enrollment Finish07/01/2027','normalized_date':'2027-07-01','type':'explicit_recruitment_cutoff','scope':tid,'timezone':'America/New_York; date only, no published hour','primary_url':t['url'],'evidence_refs':refs([t['url']])});outcome='explicit_future_cutoff_not_guaranteed_intake_until_then';unperformed=[]
 if tid=='csu-brain-cart-verdinexor':outcome='future_stored_date_no_passed_cutoff';question='The stored recruitment_end must remain distinguished from structured study end dates; future study period does not guarantee open recruitment.'
 if tid=='jp-tokyo-feline-tcc-lapatinib':
  dates.append({'raw_text':'本臨床試験は目標症例数に達したため、2026年10月31日をもって終了','normalized_date':'2026-10-31','type':'study_end_with_explicit_already_full_enrollment','scope':'Tokyo feline TCC lapatinib cohort','timezone':'Asia/Tokyo; no published hour','primary_url':'https://www.vm.a.u-tokyo.ac.jp/vmc/aboutus/research/','evidence_refs':refs(['https://www.vm.a.u-tokyo.ac.jp/vmc/aboutus/research/'])});outcome='fully_enrolled_ended_remains_hidden_paid_drug_access_is_separate';unperformed=[]
 if tid=='jp-nvlu-survivin-peptide-vaccine-2026':
  dates.append({'raw_text':'研究期間2021年9月1日〜2027年3月31日','normalized_date':'2027-03-31','type':'research_project_period_not_explicit_enrollment_deadline','scope':'NVLU survivin vaccine','timezone':'Asia/Tokyo; no published hour','primary_url':'https://www.nvlu.ac.jp/amedical/clinical-research/index.html','evidence_refs':refs(['https://www.nvlu.ac.jp/amedical/clinical-research/index.html'])});outcome='AMBIGUOUS_project_period_not_intake_guarantee';question='Canonical wording promises recruitment through March31,2027 although primary labels a research period; owner decision retained.';unperformed=[]
 if tid=='ucd-oral-fluorescence-surgery':outcome='AMBIGUOUS_study_period_timezone';question='Structured study period July1,2026–June30,2028 differs by one day from prior note; not automatically a recruitment cutoff.'
 if tid in {x['trial_id'] for x in notes['issues'].values() if x['state'] in ['BLOCKED','OWNER_DECISION']}:unperformed=[] # Exact unavailable/medical decisions are in the individually reviewed issue ledger, not silently forgotten.
 rows.append({'record_id':tid,'compared_at':now(),'previous_verified':o.get('verified'),'current_verified':t.get('verified'),'primary_urls':urls,'current_primary_evidence':[{'url':d['url'],'evidence_ref':d['evidence_file'],'original_read_at':d['completed_at'],'method':d['method']} for d in valid],'Web_evidence':[{k:a[k] for k in ['url','evidence_file','completed_at','freshness']} for a in web],'actual_new_attempts':attempts,'dates':dates,'comparison_result':outcome,'extension_confirmed':False,'matching_before':tid in B['public_ids'],'matching_after':tid in B['public_ids'],'question':question,'unperformed_steps':unperformed})
write(R/'deadline-review.json',{'run_id':R.name,'baseline_sha':'519c8189e244e3c4acd924f21c7059828fae7f55','compared_at':now(),'baseline_ids':B['catalog_ids'],'scope':'All315canonical records scanned independently of roster equality and deferred deep reviews; per-record current origin text, Web cache and restrictions remain distinct. Keyword candidates are not adjudicated recruitment deadlines.','rows':rows,'additional_semantic_findings':[{'source':'NVLU','finding':'October30,2026 belongs to the MUO/MSC nononcology project research period; it is not the survivin cancer enrollment deadline.'},{'source':'Alfort','finding':'CarboPop June2022 is a study-end period for pharmacokinetic research; TG6002 end is explicitly undefined, not a missed cutoff.'},{'source':'BluePearl','finding':'Until2026 describes a study period; closed Paccal enrollment remains independently established by sponsor/CASTR, not by interpreting that year as an exact cutoff.'}]})
print('deadline coverage',len(rows),'current primary',sum(bool(x['current_primary_evidence']) for x in rows),'public current primary',sum(x['matching_after'] and bool(x['current_primary_evidence']) for x in rows),'unperformed',sum(bool(x['unperformed_steps']) for x in rows))
