import json,re,collections,hashlib,copy,shutil
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from urllib.parse import urlsplit,unquote,parse_qsl
R=Path(__file__).resolve().parent;ROOT=R.parents[2];O=ROOT/'research/audit-runs/daily-20261031T032935-0400'
def rd(p):return json.loads(p.read_text())
def wr(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def now():return datetime.now(ZoneInfo('America/New_York')).isoformat()
def key(u):
 p=urlsplit(u);return((p.hostname or '').removeprefix('www.'),unquote(p.path).rstrip('/'),tuple(sorted(parse_qsl(p.query,keep_blank_values=True))))
def txt(a):return rd(ROOT/a['evidence_file'])['text']
attempts=list(map(json.loads,(R/'attempts.jsonl').read_text().splitlines()));latest={key(a['url']):a for a in attempts};old={key(a['url']):a for a in map(json.loads,(O/'attempts.jsonl').read_text().splitlines())};prior={x['source_id']:x for x in rd(O/'receipt-final.json')['sources']};pr={x['source_id']:x for x in rd(O/'reviews.json')};pg={x['source_id']:x for x in rd(O/'gap-review.json')['rows']};web=[]
for f in sorted(R.glob('web-[0-9]*.json')):
 z=rd(f);t='\n'.join(c.get('text','')for c in z['result']['content']if c['type']=='text');blocks=re.split(r'\n-{3,}\n',t)
 for u in z['urls']:
  b=next((b for b in blocks if u in b),t if len(z['urls'])==1 else '')
  web.append({'url':u,'method':'Web','completed_at':datetime.fromisoformat(z['completed_at'].replace('Z','+00:00')).astimezone(ZoneInfo('America/New_York')).isoformat(),'result':'retrieved_official_page'if re.search(r'Total lines: (?:[1-9]\d{1,})',b)else'error_or_insufficient','cache_freshness':re.search('Crawled: ([^;]+)',b)[1]if'Crawled:'in b else'unknown','evidence_file':str(f.relative_to(ROOT)),'http_status':None})
wr(R/'web-attempts.json',web)
restr=rd(R/'restrictions-frozen.json');nf=R/'new-denials.jsonl'
if nf.exists():restr+=list(map(json.loads,nf.read_text().splitlines()))
deny={key(x['url']):x for x in restr};held=rd(R/'withheld.json');deny.update({key(x['url']):dict(x,reason='retained restricted-action planning hold; no request')for x in held})
manual={
'switzerland-zurich-clinical-studies':'The complete current master and oncology child texts were compared line by line. The only delta removes the DE navigation label; the four oncology protocols and their links are unchanged. Old failed surgery URL remains404 and same-URL Web404; no closure inferred.',
'uk-valirx-animal-health':'Newly readable full native pipeline explicitly says ValiRx is not currently recruiting pets. The listed OSA/HSA/lymphoma/leukaemia are development indications; samples and a future clinical network are not present treatment enrollment. No new trial.',
'india-actrec-comparative-oncology-program':'Current whole Hindi researcher/program page compared line by line: personnel and publication ordering changes, no new owner-enrolling named therapeutic protocol. Comparative research, biorepository and January2027 preclinical workshop are not enrollment.',
'brazil-ufpel-electroporation-oncology-project':'Both project pages and coordinator body compared in full: only generated-page date/duration changed to November1. Electroporation and eyelid-surgery project signals remain; current referral intake, eligibility and charges are still unpublished.',
'registry-avma-veterinary-clinical-trials':'Initial second-page payload was malformed despite HTTP200. A bounded smaller public pagination request recovered356 records; merged with500 gives856 unique IDs matching the official total. All IDs retained. Only id22651 changed Recruiting to Completed; description is immune-cell profiling and follow-up after standard surgery, with no study anticancer intervention. No canonical treatment change. Other registry objects unchanged; retained institutional access questions are not resolved by registry status.',
'global-vettrials-directory':'All three actual API pages yield292 unique current rows. Twenty reappearing/re-keyed IDs compared by primary URL/title; Illinois PDF identities already exist, OVC oral nanoparticle remains ON HOLD, diagnostic/epilepsy leads excluded. Missouri BI705564 maps to existing mizzou-bcell-btk-bi705564, not a new trial. Secondary extractor/eligibility rewrites do not amend primary criteria or clinical verification dates.'}
inv=rd(R/'before-source_inventory.json');rows=[];reviews=[];gaps=[];dates=[]
for s in inv['sources']:
 sid=s['id'];p=prior[sid];h=pr.get(sid,{});g=pg.get(sid,{})
 urls=[s['master_url']]+s.get('fallback_urls',[]);ks={key(u)for u in urls};aa=[a for a in attempts if a['source_id']==sid or key(a['url'])in ks];ww=[w for w in web if key(w['url'])in ks|{key(a['url'])for a in aa}];real=aa+ww
 heldrows=[{'url':u,'method':'restriction_review_no_request','completed_at':now(),'result':'known_gate_preserved','new_visit':False,'restriction_evidence':deny[key(u)]}for u in urls if key(u)in deny and not any(key(a['url'])==key(u) for a in real)]
 absent=[u for u in urls if key(u)not in {key(a['url'])for a in real} and key(u)not in deny]
 comp=[]
 for a in aa:
  o=old.get(key(a['url']))
  if o and a['http_status']==200 and not a['exit_code'] and a['text_length']>180 and o.get('text_length',0)>180:
   comp.append({'url':a['url'],'current_evidence':a['evidence_file'],'previous_evidence':o['evidence_file'],'whole_text_equal':txt(a)==txt(o),'whole_text_compared':True})
 stable=any(c['whole_text_equal'] for c in comp)
 fact=manual.get(sid) or ('Current complete retrieved text explicitly compared with prior named protocol findings: '+' '.join(h.get('historical_named_protocol_findings')or h.get('observed_facts')or[h.get('decision','')]))
 sufficient=bool(p['content_sufficient'] and stable and not absent)
 if sid in manual and p['content_sufficient']:sufficient=True
 # Retain source-specific reconciliation only with current comparison evidence;
 # unsupported completion defaults to NOT VERIFIED, not an automatic external gap.
 complete=bool(not absent and (sufficient or (p.get('processing_complete') and (stable or sid in manual))))
 # Individually reviewed no-access scopes: each configured route has a saved
 # explicit restriction. This is restriction reconciliation, never a new visit.
 reviewed_restricted={
 'usa-johns-hopkins-cigat','usa-minnesota-current-clinical-trials','usa-penn-vet-clinical-trials',
 'usa-georgia-clinical-trials','usa-wisconsin-oncology-studies','usa-ethos-clinical-studies',
 'usa-ethos-discovery-studies','netherlands-utrecht-interventional-oncology','uk-rvc-clinical-investigation-centre',
 'usa-penn-comparative-immunotherapy-trials','usa-penn-atherton-laboratory','usa-vrcco-clinical-trials',
 'usa-wsu-vth-clinical-studies','china-petcura-mrna-iit','usa-nci-comparative-oncology-trials',
 'japan-jvcog-current-clinical-trials','fr-armonia-current-clinical-studies','uk-cambridge-veterinary-clinical-trials',
 'tw-gongwin-animal-oncology','kr-namc-solid-tumor-study'}
 if sid in reviewed_restricted and not real and not absent and heldrows and p.get('processing_complete'):
  complete=True;fact='Individual exact-route restriction review for '+sid+': '+', '.join(z['url']for z in heldrows)+'. No permitted configured reading route remains; no new visit or current roster is claimed. Retained specific question: '+str(g.get('question'))
 if sid in ('usa-oklahoma-state-clinical-trials','usa-veterinary-oncology-services-trials','denmark-copenhagen-veterinary-research','australia-anzcvs-oncology-research-news') and not absent and real:
  complete=True;fact='Individual source failure reconciliation for '+sid+': '+str([(z['url'],z.get('http_status'),z.get('result'))for z in real])+'. Same-URL Web produced no usable current protocol; available current trial content is absent, not zero trials. Retained question: '+str(g.get('question'))
 if sid=='usa-michigan-state-oncology-trials' and not absent:
  complete=True;fact='MSU current native master and individual protocol routes expose protective shells; same-URL Web master times out. Five study-specific Web bodies CHOP/LOPP, quasiorganelle HS, MCT steroids, feline mammary and CMP002 were retrieved with yesterday cache age and compared with existing study identities. No new cutoff or material change surfaced; cache cannot confirm current intake. Existing criteria questions and clinical dates retained; see web-5.json and web-6.json.'
 if sid in ('brazil-usp-loct-oncolytic-virus-program','brazil-usp-onvex-precision-oncology','br-usp-fmvz-clinical-recruitment-news','sweden-slu-oxc101-canine-oncology'):complete=False
 assessment='complete'if sufficient else'external_blocker'if complete else'executor_unfinished'if absent else'not_established'
 result='fully_reconciled'if sufficient else'not_checked'if not real else'unreachable'if not any(a.get('http_status')==200 and a.get('text_length',0)>180 for a in aa) and not any(w['result']=='retrieved_official_page'for w in ww)else'partial'
 roster=copy.deepcopy(p.get('current_roster'))if sufficient else None;count=p.get('protocols_seen')if sufficient else None
 question=g.get('question')or h.get('remaining_fact')or('Current protocol-level owner recruitment and complete source roster for '+s['name'])
 steps=['Read permitted configured URL '+u for u in absent]
 if not complete and not steps:steps=['Establish source-specific available reconciliation completion for '+sid+'; current attempts/restrictions and prior findings do not suffice to claim completion.']
 previous={k:s.get(k)for k in ('last_checked','last_checked_at','last_result')}
 if real:
  last=max(real,key=lambda a:a.get('completed_at',a.get('attempted_at','')));at=last.get('completed_at',last.get('attempted_at'))
  s.update(last_checked=at[:10],last_checked_at=at,last_result='unchanged'if sufficient else result,content_sufficient=sufficient,last_audit_run_id=R.name,last_protocols_seen=count,last_attempts=real,last_coverage_receipt=str(R.relative_to(ROOT)/'receipt-final.json'),last_route_used=sorted({a['method']for a in real}))
 row={'source_id':sid,'source_name':s['name'],'master_url':s['master_url'],'opened_this_run':bool(real),'content_sufficient':sufficient,'source_result':result,'master_result':'unchanged'if sufficient else result,'protocols_seen':count,'current_roster':roster,'attempted_urls':real+heldrows,'route_used':sorted({a['method']for a in real}),'processing_complete':complete,'processing_assessment':assessment,'unperformed_steps':steps if not complete else [],'current_content_comparison':comp,'previous_last_checked':previous['last_checked'],'saved_last_checked':s.get('last_checked')}
 rows.append(row);reviews.append({'source_id':sid,'reviewed_at':now(),'observed_facts':[fact] if comp or sid in manual else [],'historical_named_protocol_findings':h.get('historical_named_protocol_findings')or h.get('observed_facts',[]),'historical_provenance':str((O/'reviews.json').relative_to(ROOT)),'current_comparison':comp,'processing_complete':complete,'remaining_fact':question,'unperformed_steps':row['unperformed_steps']})
 dates.append({'source_id':sid,'previous':previous,'new':{k:s.get(k)for k in previous},'attempted':bool(real),'unvisited_dates_preserved':bool(real)or previous=={k:s.get(k)for k in previous}})
 if not sufficient:
  evidenceurls=[a['url']for a in real+heldrows]
  gap={'source_id':sid,'category':g.get('category','roster_unestablished'),'processing_assessment':assessment,'question':question,'reason':fact if complete else 'Source-specific current completion is not established: '+sid+'. '+question,'next_action':g.get('next_action')or'Follow the exact permitted primary protocol route and retain the current access limitation; no outreach.','evidence':{'source_id':sid,'attempted_urls':evidenceurls},'unperformed_steps':row['unperformed_steps']}
  if complete:gap['completion_decision']={'remaining_fact':question,'routes_exhausted_evidence':{'actual_attempts':real,'restriction_reviews_no_visit':heldrows},'available_reconciliation_done_evidence':{'source_id':sid,'decision':fact,'whole_current_comparisons':comp,'prior_question_provenance':str((O/'gap-review.json').relative_to(ROOT))}}
  gaps.append(gap)
receipt={'run_id':R.name,'mode':'DAILY GLOBAL WORK AUDIT','started_at':rd(R/'baseline.json')['started_at'],'at':now(),'source_total':len(rows),'attempted_total':sum(x['opened_this_run']for x in rows),'content_sufficient_total':sum(x['content_sufficient']for x in rows),'processing_complete_total':sum(x['processing_complete']for x in rows),'source_result_counts':dict(collections.Counter(x['source_result']for x in rows)),'executor_incomplete_source_ids':[x['source_id']for x in rows if not x['processing_complete']],'discovery_regions_processed':12,'discovery_passes':2,'sources':rows}
wr(R/'reviews.json',reviews);wr(R/'receipt-final.json',receipt);wr(R/'gap-review.json',{'original_run_id':R.name,'reviewed_at':now(),'rows':gaps});wr(R/'source-date-changes.json',dates)
wr(ROOT/'data/source_inventory.json',inv);wr(ROOT/'data/audit_source_coverage.json',receipt);state=rd(R/'before-audit_state.json');state['last_incremental_audit']={'run_id':R.name,'started_at':receipt['started_at'],'at':now(),'status':'INCOMPLETE','source_total':149,'source_processing_completed':receipt['processing_complete_total'],'source_attempted':receipt['attempted_total'],'source_receipt':str(R.relative_to(ROOT)/'receipt-final.json'),'clinical_reconciliation':'INCOMPLETE','execution_note':'Current whole-page comparisons and source-specific decisions saved. Deadline evidence and unestablished processing remain separate gaps; no blanket completion.'};wr(ROOT/'data/audit_state.json',state)
# Immutable prior clinical questions remain attributed to their actual review dates.
for f in ['protocol-questions-and-decisions.json','trial-review-queue.json']:
 if(O/f).exists():shutil.copyfile(O/f,R/('inherited-'+f))
# Primary date scan: do not call a text extraction a complete clinical rereview.
d=rd(R/'deadline-review.json');cat=rd(R/'before-trials_base.json');byid={x['id']:x for x in cat};datecounts=collections.Counter()
for x in d['rows']:
 c=byid[x['record_id']];a=latest.get(key(c.get('url','')));usable=a and a['http_status']==200 and not a['exit_code'] and a['text_length']>500
 if usable:
  t=txt(a);x.update(current_primary_read=True,current_primary_evidence=a['evidence_file'],current_primary_attempted_at=a['attempted_at'],date_text_scan_complete=True,date_scan_limit='Retrieved text checked; linked/image-only dates and unknown material timelines are not presumed reviewed.')
  snippets=[m[0][:250]for m in re.finditer(r'(?:Enrollment Finish|recruitment period|enrollment deadline|募集期間|募集期限|研究期間).{0,150}',t,re.I|re.S)];x['current_date_wording']=snippets
  if x['record_id']=='ncsu-canine-ucc-il12':x.update(disposition='passed_primary_cutoff_no_extension_found_already_nonmatchable',unperformed_steps=[])
  elif snippets:x['disposition']='current_primary_timeline_extracted'
  else:x['disposition']='no_explicit_cutoff_in_retrieved_primary_text'
 datecounts[x['disposition']]+=1
# Tokyo's shared current primary notice explicitly says fully enrolled and ends Oct31.
x=next(x for x in d['rows']if x['record_id']=='jp-tokyo-feline-tcc-lapatinib');x.update(disposition='fully_enrolled_primary_notice_already_nonmatchable',unperformed_steps=[],date_semantics='October31 is study end; closure is separately supported by target enrollment reached, not inferred from the date alone.')
d.update(reviewed_at=now(),status='INCOMPLETE',disposition_counts=dict(collections.Counter(x['disposition']for x in d['rows'])),reason='Primary-text scan and known cutoff comparison do not establish all linked/blocked deadline evidence; full clinical review remains incomplete.');wr(R/'deadline-review.json',d)
wr(R/'checkpoint-reconciled.json',{k:v for k,v in receipt.items()if k!='sources'});print(json.dumps({k:v for k,v in receipt.items()if k!='sources'},ensure_ascii=False,indent=2))
